#ifndef PIREDUCTION_H
#define PIREDUCTION_H

double pi_reduction_calc(long int);

#endif /* PIREDUCTION_H */
