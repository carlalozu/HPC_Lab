#ifndef PICRITICAL_H
#define PICRITICAL_H

double pi_critical_calc(long int);

#endif /* PICRITICAL_H */
