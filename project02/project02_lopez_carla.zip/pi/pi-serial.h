#ifndef PISERIAL_H
#define PISERIAL_H

double pi_serial_calc(long int);

#endif /* PISERIAL_H */
